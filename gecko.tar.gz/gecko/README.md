# 🦎 Gecko — FOSS Infrastructure as Code

> *Move fast. Grip hard. Shed the old.*

Gecko is a **FOSS-first Infrastructure as Code framework** for teams who believe infrastructure tooling should be open, composable, and opinionated in the best possible ways.

Built in Go. No phone-home telemetry. No proprietary providers. No cloud vendor lock-in.

---

## Command Reference

Gecko's CLI is themed around gecko anatomy and behavior. Every command maps to something a real gecko does.

| Command | Alias | What It Does | The Metaphor |
|---|---|---|---|
| `gecko hatch` | `init` | Initialize a new project | 🥚 A gecko hatching from its egg — new life begins |
| `gecko crawl` | `plan` | Preview changes (dry run) | 🦶 Crawling carefully before striking — survey first |
| `gecko grip` | `apply` | Apply infrastructure changes | 🤲 Gripping the wall — commit and hold |
| `gecko molt` | `destroy` | Tear down all infrastructure | 💀 Shedding everything — start fresh |
| `gecko bask` | `status` | Infrastructure status dashboard | ☀️ Basking in the sun — take stock |
| `gecko tail` | `logs` | Stream live logs | 🔍 Following the tail — track what moves |
| `gecko lick` | `inspect` | Deep-inspect a resource | 👅 Licking to sense — full visibility |
| `gecko shed` | `upgrade` | Upgrade providers/framework | 🐍 Shedding old skin — embrace the new |
| `gecko hide` | `secrets` | Manage encrypted secrets | 🫙 Hiding in a crevice — keep it secret |
| `gecko burrow` | `import` | Import existing resources | 🕳️ Burrowing into terrain — take control |
| `gecko scale` | `resize` | Scale resources up/down | 📊 Adjusting scales — right-size anything |
| `gecko clutch` | `workspace` | Manage stacks/workspaces | 🥚 An egg clutch — each one isolated |

---

## Quick Start

```bash
# Install
go install github.com/gecko-iac/gecko@latest

# Create a new project with Kubernetes + Proxmox
gecko hatch my-homelab --providers k8s,proxmox --workspace dev

# Preview what Gecko would do
gecko crawl

# Apply your infrastructure
gecko grip

# Watch live logs
gecko tail --resource k8s:deployment.api-server --follow

# Check status
gecko bask

# Inspect a specific resource
gecko lick k8s:deployment.api-server
```

---

## Project Structure

After `gecko hatch`, your project looks like:

```
my-homelab/
├── gecko.json              # Project config: providers, backend, workspaces
├── .geckoignore            # Files to exclude from gecko operations
├── stacks/
│   ├── dev/
│   │   └── main.go        # Dev workspace stack declaration
│   ├── staging/
│   │   └── main.go
│   └── prod/
│       └── main.go
├── modules/                # Reusable infrastructure modules
│   ├── monitoring/
│   └── networking/
└── .gecko/
    ├── state/              # Local state files (switch to remote for teams)
    └── plans/              # Saved crawl plans
```

---

## Stack Declaration

Gecko stacks are written in Go (or Python / TypeScript / HCL):

```go
package main

import (
    "github.com/gecko-iac/gecko/core"
    "github.com/gecko-iac/gecko/providers/k8s"
    "github.com/gecko-iac/gecko/providers/proxmox"
)

func main() {
    stack := core.NewStack("my-homelab", "main", "dev")

    // Register FOSS providers
    stack.RegisterProvider(k8s.NewProvider(nil))
    stack.RegisterProvider(proxmox.NewProvider(nil))

    // Declare a Kubernetes namespace
    nsID := stack.Resource(core.ResourceArgs{
        Type: "k8s:namespace",
        Name: "monitoring",
        Inputs: core.Inputs{
            "name": "monitoring",
            "labels": map[string]string{
                "managed-by": "gecko",
            },
        },
    })

    // Prometheus deployment depending on the namespace
    promID := stack.Resource(core.ResourceArgs{
        Type:      "k8s:deployment",
        Name:      "prometheus",
        DependsOn: []core.ResourceID{nsID},
        Inputs: core.Inputs{
            "namespace": "monitoring",
            "image":     "prom/prometheus:v2.50.0",
            "replicas":  1,
            "ports":     []int{9090},
        },
    })

    // Grafana depends on Prometheus
    _ = stack.Resource(core.ResourceArgs{
        Type:      "k8s:deployment",
        Name:      "grafana",
        DependsOn: []core.ResourceID{promID},
        Inputs: core.Inputs{
            "namespace": "monitoring",
            "image":     "grafana/grafana:10.3.0",
            "replicas":  1,
            "ports":     []int{3000},
            "env": map[string]string{
                "GF_SECURITY_ADMIN_PASSWORD": "gecko.secret(\"grafana.admin.password\")",
            },
        },
    })
}
```

---

## FOSS Provider Ecosystem

Gecko ships with providers for the best open-source infrastructure tools:

| Provider | Resources | Notes |
|---|---|---|
| **kubernetes** | 22 resource types | Works with k3s, k0s, Talos, kubeadm |
| **proxmox** | VMs, LXC, storage, networks | Full Proxmox VE 8.x support |
| **nomad** | Jobs, namespaces, volumes | HashiCorp Nomad clusters |
| **gitea** | Repos, orgs, users, webhooks, runners | Self-hosted Git forge |
| **minio** | Buckets, policies, users | S3-compatible object storage |
| **vault** | Secrets, policies, auth methods | HashiCorp Vault |
| **keycloak** | Realms, clients, users, roles | Identity and SSO |
| **wireguard** | Peers, networks | VPN mesh networking |
| **nfs** | Exports, mounts | Network file systems |
| **postgresql** | Databases, roles, extensions | Managed Postgres |

---

## State Backends

State can be stored anywhere:

```json
// gecko.json
{
  "backend": {
    "type": "local"
  }
}
```

```json
// Remote: S3-compatible (MinIO works!)
{
  "backend": {
    "type": "s3",
    "config": {
      "endpoint": "https://minio.local:9000",
      "bucket": "gecko-state",
      "prefix": "my-homelab/"
    }
  }
}
```

Supported: `local`, `s3` (+ MinIO), `gcs`, `etcd`, `postgres`

---

## Secrets

```bash
# Store an encrypted secret
gecko hide set --key grafana.admin.password --value supersecret

# List all secrets
gecko hide

# Use in your stack
gecko.secret("grafana.admin.password")
```

Secrets are encrypted with AES-256-GCM. Environment variable fallback: `GECKO_SECRET_<KEY>`.

---

## Workspaces

```bash
# List workspaces
gecko clutch

# Create a new workspace
gecko clutch new --name production

# Switch active workspace
gecko clutch select production

# Plan against a specific workspace without switching
gecko crawl --workspace staging
```

---

## Multi-Runtime Support

Write your stacks in the language you know:

```python
# Python
import gecko

stack = gecko.Stack(name="my-homelab", workspace="dev")
stack.register_provider(gecko.providers.k8s())

ns = gecko.Resource(stack, "k8s:namespace", name="monitoring",
    inputs={"name": "monitoring"})
```

```typescript
// TypeScript
import * as gecko from "@gecko-iac/gecko";

const stack = new gecko.Stack({ name: "my-homelab", workspace: "dev" });
stack.registerProvider(new gecko.providers.k8s.Provider());

const ns = new gecko.Resource(stack, "k8s:namespace", {
  name: "monitoring",
  inputs: { name: "monitoring" },
});
```

---

## Architecture Overview

```
┌─────────────────────────────────────────────────┐
│                  gecko CLI                       │
│  hatch  crawl  grip  molt  bask  tail  lick ...  │
└────────────────────┬────────────────────────────┘
                     │
┌────────────────────▼────────────────────────────┐
│              Gecko Engine                        │
│  ┌──────────┐  ┌──────────┐  ┌───────────────┐  │
│  │  Graph   │  │  Planner │  │  Applier      │  │
│  │ (DAG)    │  │  (Diff)  │  │  (Lifecycle)  │  │
│  └──────────┘  └──────────┘  └───────────────┘  │
└────────────────────┬────────────────────────────┘
                     │
┌────────────────────▼────────────────────────────┐
│              State Backend                       │
│         local  /  s3  /  etcd  /  postgres       │
└────────────────────┬────────────────────────────┘
                     │
┌────────────────────▼────────────────────────────┐
│              Provider Layer                      │
│   k8s   proxmox   nomad   gitea   minio   vault  │
└─────────────────────────────────────────────────┘
```

---

## Building Providers

Implement the `core.Provider` interface:

```go
type Provider interface {
    Name() string
    Version() string
    SupportedTypes() []ResourceType

    Configure(ctx context.Context, config map[string]interface{}) error
    Validate(ctx context.Context, args ResourceArgs) error

    Create(ctx context.Context, args ResourceArgs) (*ResourceState, error)
    Read(ctx context.Context, id ResourceID, externalID string) (*ResourceState, error)
    Update(ctx context.Context, current *ResourceState, desired ResourceArgs) (*ResourceState, error)
    Delete(ctx context.Context, state *ResourceState) error

    Import(ctx context.Context, resourceType ResourceType, externalID string) (*ResourceState, error)
    Diff(ctx context.Context, current *ResourceState, desired ResourceArgs) (*Diff, error)
}
```

---

## Design Principles

1. **FOSS-first** — every provider targets open-source infrastructure
2. **Multi-runtime** — Go, Python, TypeScript, HCL are all first-class
3. **Dependency graph** — declare resources, Gecko figures out the order
4. **Drift detection** — Gecko continuously reconciles declared vs actual state
5. **State resilience** — state saved after each resource, never lost on partial failure
6. **Zero lock-in** — state format is plain JSON, providers are plugins

---

## License

Apache 2.0. Build what you want, self-host everything, own your infrastructure.

---

*🦎 Infrastructure that grips, scales, and never lets go.*
